package interfaces;

//Name of the package same as the interfaces directory
//package interfaces;
//Room class under this interfaces package
import java.lang.*;
//create an interface named Room
public interface Room{

public void service();
public int getRoomNo();
public void setRoomNo(int roomNo);
}
